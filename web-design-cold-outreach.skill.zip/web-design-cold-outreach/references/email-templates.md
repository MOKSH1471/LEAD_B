# Email templates and copy rules

## Copy rules (apply to every email)

1. **One observed issue, not a list.** Naming three problems reads as a template email. Naming one specific thing you actually saw proves a human (or a very good bot) looked.
2. **Connect it to money, not aesthetics.** "Your site looks dated" is a design complaint. "Your site takes 6 seconds to load on mobile, and most people looking for an emergency plumber leave before then" is a business problem. Always land on the business consequence.
3. **One small piece of proof.** A specific number, a before/after, a one-line result from a comparable business. Not a portfolio dump.
4. **One ask, low friction.** "Worth a 15-minute call?" beats "Let me know if you'd like to discuss further, happy to answer any questions, feel free to reach out." Pick one CTA per email.
5. **Length: under ~130 words for the Day 1 email.** If it needs scrolling, it needs cutting.
6. **Never promise guaranteed results, guaranteed rankings, or a specific traffic/revenue number you can't back up.** This is both an honesty issue and, for regulated niches (law, dental, healthcare, finance), a compliance issue — several of these industries have advertising rules that prohibit exactly this.
7. **No spam-trigger clichés.** Avoid "Act now," "Free," "Guarantee," ALL CAPS subject lines, excessive exclamation points, and stock phrases like "I hope this email finds you well."
8. **Sign as a real person with a real role**, not "The Team" — pick a named project owner and stay consistent across the sequence.

## Subject line bank

Rotate these; don't reuse the exact same line across a whole batch. Personalize the bracketed part wherever possible — a subject with the business's own name or a real detail consistently outperforms a generic one.

- `Quick question about [Business Name]'s website`
- `Noticed something on [Business Name]'s site`
- `[Business Name] — one thing costing you calls`
- `Your [City] competitors and mobile speed`
- `A 90-second look at [Business Name]'s booking flow`
- `[Business Name]'s reviews are great — the site undersells them`
- `Following up — [Business Name]`  *(day 16 / breakup only)*

## Day 1 — Initial email

**Structure:** greeting → the one observed issue → the business consequence → light proof or credibility signal → the ask → simple sign-off.

**Template — home services (HVAC/plumbing/electrical, remodelers, cleaning):**

> Hi [First Name],
>
> I was looking at [Business Name]'s site and noticed [specific issue — e.g., "there's no way to request a quote without calling during business hours"]. For an emergency-driven trade like yours, that's likely costing you calls from people searching at night or on weekends.
>
> We build mobile-first sites for [niche] companies in [metro] with a quote/booking flow built in — most of our clients see calls pick up within the first few weeks of launch.
>
> Worth a 15-minute call this week to see if it's a fit?
>
> [Name]
> [Agency Name] — [domain email]

**Template — med spa / dental (visual, booking-driven):**

> Hi [First Name],
>
> Your reviews for [Business Name] are excellent, but the website doesn't really show that off — [specific issue, e.g., "the gallery is buried three clicks deep" or "there's no online booking, just a phone number"]. For a visually-driven business like a med spa, that gap usually shows up as fewer online bookings than the reviews would suggest.
>
> We design booking-first sites for [niche] practices, built around before/after galleries and provider credentials.
>
> Open to a quick 15-minute call to walk through what we'd change?
>
> [Name]
> [Agency Name] — [domain email]

**Template — professional services (law, accounting, home-care):**

> Hi [First Name],
>
> I noticed [specific issue, e.g., "there's no way to start an intake or schedule a consult from the site"] on [Business Name]'s website. For [niche], that's often the difference between a visitor calling you and calling the next firm on the search results page.
>
> We build sites for [niche] practices with [relevant feature — secure intake, scheduling, service-area pages] built in from the start.
>
> Would a 15-minute call make sense to see if this is worth fixing?
>
> [Name]
> [Agency Name] — [domain email]

## Day 3 — LinkedIn connection

No pitch. Reference the same observation in one line, nothing more:

> Hi [First Name] — sent a quick note about [Business Name]'s website [yesterday/a couple days ago]. Connecting here in case it's more your speed. No pressure either way.

## Day 5 — Teardown

Attach or link a 60–90 second Loom, or two annotated screenshots. Keep the email itself short — the teardown does the talking:

> Hi [First Name],
>
> Put together a quick [Loom / two screenshots] showing exactly what I meant about [issue] on [Business Name]'s site, plus one quick fix that would likely help: [link].
>
> Happy to walk through it live if useful.
>
> [Name]

## Day 10 — Scope and price

By now they've seen the issue twice. Get concrete:

> Hi [First Name],
>
> Following up with specifics: a rebuild along the lines we discussed would be a [Starter $X–$X / Growth $X–$X] project, [page count] pages, delivered in [timeframe]. If ongoing SEO/maintenance is useful afterward, that runs $[X]–$[X]/month.
>
> If it's helpful, I can send a one-page scope so you can see exactly what's included.
>
> [Name]

## Day 16 — Close the loop

Short, no guilt, real opt-out:

> Hi [First Name],
>
> Haven't heard back, so I'll leave this here — happy to pick it back up anytime if the timing's better later. If you'd rather not hear from us again, just let me know and I'll take you off the list.
>
> [Name]

## Adapting when details are thin

If the bot only has a business name, niche, and city — no specific site observation yet — do not fabricate one. Use a bracketed placeholder like `[SPECIFIC ISSUE — confirm before sending]` so a human or a verification step fills it in before the email actually goes out. Sending an email that claims to have "noticed" something nobody actually looked at defeats the entire point of trigger-based outreach and risks looking worse than a generic template.
