# Market research reference

Source: primary analysis is the sourced, dated research report ("U.S. SMB Web Design Opportunity Map," evidence current through Sept 4, 2026), which combines Census Business Formation Statistics, SBA metro profiles, the 2026 Milken Best-Performing Cities index, and niche-specific industry sources (AmSpa, ADA, BLS, ABA, IRS, EPA, Harvard JCHS, BSCAI, The Knot) with an explicit, disclosed analyst model for the parts no public dataset covers (budgets, decision speed, agency saturation, ghosting risk). Three additional independent research passes were cross-checked against it; where they diverge, that's noted below rather than silently merged.

**Read the confidence column.** "High" means grounded in a named public dataset. "Medium" or "medium-low" means modeled/triangulated — useful as a starting hypothesis, not a fact to quote to a prospect.

---

## Table 1 — Niches, ranked

| Tier | Niche | Practical budget / retainer | Decision speed | Why now | Where to source contacts | Red flags | Confidence |
|---|---|---|---|---|---|---|---|
| A | HVAC, plumbing, electrical (5–50 staff) | $1.5k–$4k build / $750–$2k mo | Fast: 7–21 days | Emergency/mobile search behavior; reviews and quote speed directly drive booked calls; 2025–26 refrigerant transition creating fresh consumer questions | Google Maps, BBB, Yelp, state license lists, ACCA, PHCC, local Home Builders Associations, LinkedIn owner/GM | One-truck operators, no dispatcher/CRM, "pay per lead only," cash-only, weak license/review history | High on demand; medium on budget/cycle |
| A | Remodelers, roofers, specialty contractors | $2k–$5k build / $1k–$3k mo | Fast-medium: 10–30 days | Large repair/remodel market; visual proof and service-area SEO reward strong sites; 2026 remodeling growth is slowing, raising the value of conversion efficiency | Google Maps, Houzz, NARI, NRCA, NAHB/local HBAs, permit/license lists, supplier referrals | Storm chasers, brand-new LLCs, poor reviews, no license/insurance, wants guaranteed rankings | High/medium |
| A | Medical spas / aesthetics clinics | $3k–$5k build / $1.5k–$4k mo | Fast: 7–21 days | Industry exceeds $17B, growing $1B+/year; intense local competition raises the value of credential/before-after/booking pages | Google Maps, Yelp, RealSelf, AmSpa, local chamber/women-owner groups, Instagram/LinkedIn founders | Unclear medical oversight, risky treatment claims, ad-account problems, expects you to own clinical/legal compliance | High on economics; medium on sales-cycle |
| A | Dental / orthodontic practices | $2.5k–$5k build / $1k–$3k mo | Medium: 14–45 days | ADA calls a responsive site a practice's most powerful marketing tool; online scheduling and insurance/financing clarity reduce patient friction | ADA Find-a-Dentist, state dental boards, Healthgrades, Zocdoc, Google Maps, LinkedIn practice managers | DSO/corporate procurement, retiring solo owner with no internal champion, wants PHI in ordinary web forms | High on need; medium on budget/cycle |
| B | Home-care / senior-care agencies | $2.5k–$5k build / $1k–$3k mo | Medium: 14–45 days | BLS projects 18% employment growth 2025–35 for home-health/personal-care aides; agencies need trust, caregiver recruiting, and referral intake | Medicare Care Compare, state health/licensing lists, HCAOA, Google Maps, hospital/elder-law referral partners | License pending, franchise-locked to a corporate site, Medicaid-only cash flow, high caregiver churn | High on demand; medium on willingness-to-pay |
| B | Small law firms (estate, family, immigration, employment; 2–20 lawyers) | $3k–$5k build / $1.5k–$4k mo | Medium: 14–45 days | Intake responsiveness is weak industry-wide; site can connect SEO, 24/7 screening, scheduling, and case intake — but every claim must follow state bar advertising rules | State/local bar directories, Avvo, Justia, FindLaw, LinkedIn partners, chamber lists | **Avoid personal-injury** (SEO arms race, aggressive incumbents), guaranteed-outcome language, referral-fee/solicitation ethics issues | High on value; medium-low on acquisition effort |
| B | Accounting, bookkeeping, tax firms | $1.5k–$4k build / $750–$2k mo | Fast-medium: 7–30 days outside Feb–Apr | IRS requires a Written Information Security Plan; a redesign creates a clean boundary between marketing content and secure client portals | IRS preparer directory, CPAverify/state CPA societies, QuickBooks ProAdvisor directory, LinkedIn, chambers, BNI groups | Seasonal solo preparer, wants client files/SSNs through ordinary forms, DIY/static-site mindset | High on compliance need; medium on budget |
| C | Veterinary clinics | Not separately modeled in primary source; treat similarly to dental (owner willingness to spend, sticky retainers) | Slow — owner-led, deliberate decisions | Strong owner spend willingness and sticky retainer fit reported across secondary sources, but not independently sourced here | State veterinary boards, Google Maps, AAHA, LinkedIn practice owners | Slow decision cycle — budget more outreach patience, don't expect a fast close | Medium-low (secondary-source only) |
| C | Real estate agents | $2.5k–$8k range reported in one secondary source (IDX/MLS-driven) | Fast: 2–4 weeks | Commission-driven urgency, IDX/MLS integration is close to mandatory | Zillow/Realtor.com agent pages, local MLS/board directories, LinkedIn | High churn if the agent's deal volume dips; often price-sensitive individually rather than as a firm | Medium-low (secondary-source only) |
| C | Behavioral-health group practices | $1.5k–$4k build / $750–$2k mo | Fast-medium: 7–30 days | BLS projects 18% growth for counselors 2025–35; directories and digital intake are increasingly the norm | Psychology Today, TherapyDen, Zocdoc, SAMHSA FindTreatment.gov, state license boards | Solo clinician with a full caseload (no capacity to benefit), PHI in generic forms, payer dependency | High on demand; medium-low on budget |
| C | Wedding/event venues and premium vendors | $2k–$5k build / $500–$1.5k mo | Fast-medium: 7–30 days | ~2M US couples married in 2025 in a $100B+ market; galleries, pricing guidance, and tour booking directly support conversion | The Knot, WeddingWire, Peerspace, NACE, local wedding Facebook groups, venue associations | Seasonal cash stress, Instagram-only DIY mindset, low review volume | High on market size; medium on payment/cycle |
| C | Commercial cleaning / facility-service contractors | $1.2k–$3.5k build / $500–$1.5k mo | Fast: 7–21 days | Industry expects growth and is investing in tech/automation; a credible capability site helps win recurring B2B bids | ISSA, BSCAI, Google Maps, BBB, chamber vendor lists, property-manager groups | Residential-only solo cleaner, commodity price bidder, no insurance/bonding | Medium-high on market; medium-low on budget |

**Excluded for the first 90 days:** restaurants, generic e-commerce startups, coaches, and pre-revenue startups. Easy to source, but combine high churn, DIY-platform substitution, fragile cash flow, and heavy price shopping. Take these only through referral, upfront fixed scope, or a clearly visible growth trigger.

---

## Table 2 — States and metros, ranked

Scores are 1–5 (higher is better for us); "web competition" is inverted so 5 = *less* crowded, better for the seller.

| Rank | State (priority metros) | SMB/startup activity | Spend | Web competition (5=lower) | Pay proxy | Digital readiness | Read |
|---|---|---|---|---|---|---|---|
| 1 | **Texas**: Dallas-Fort Worth, Austin-Round Rock, Houston, San Antonio | 5.0 | 4.4 | 3.3 | 4.2 | 4.5 | Largest sourceable pool. DFW suburbs are the best first blend; Austin is digitally mature but agency-crowded; Houston is vast but noisy. |
| 2 | **North Carolina**: Raleigh-Cary, Charlotte-Concord-Gastonia | 4.7 | 4.2 | 4.0 | 4.4 | 4.6 | Best balanced market: rapid growth, professional buyers, strong digital readiness, less saturated than Austin/Miami. |
| 3 | **Utah**: Salt Lake City-Murray, Provo-Orem-Lehi | 4.3 | 4.2 | 4.0 | 4.5 | 4.8 | Digitally fluent, strong operating culture. Smaller list — specialize by niche rather than going generic. |
| 4 | **Florida**: Tampa-St. Petersburg-Clearwater, Orlando-Kissimmee-Sanford, Jacksonville | 5.0 | 4.1 | 3.4 | 3.7 | 4.3 | High volume and local-service demand, but qualify strictly — lots of microbusinesses, tourism exposure, franchises. |
| 5 | **Virginia**: Arlington-Alexandria-Reston, Richmond | 4.0 | 4.8 | 3.2 | 4.7 | 4.7 | High-income, professional-services-heavy buyers. Northern Virginia is more agency-crowded; Richmond is easier at a lower ticket. |
| 6 | **South Carolina**: Charleston-North Charleston, Greenville-Anderson | 4.3 | 4.0 | 4.1 | 4.1 | 4.1 | Charleston strong for weddings/home services/aesthetics; Greenville is a quieter B2B/home-service play. Smaller absolute lists. |
| 7 | **Arizona**: Phoenix-Mesa-Chandler | 4.6 | 4.2 | 3.5 | 4.1 | 4.4 | Large, fast-growing, strong home-service/dental/aesthetics fit. Competitive but easier than coastal CA — focus Mesa/Chandler/Scottsdale. |
| 8 | **Tennessee**: Nashville-Davidson-Murfreesboro-Franklin | 4.4 | 4.2 | 3.2 | 4.1 | 4.4 | High growth, premium local services; central Nashville's creative/agency scene is crowded — prospect the suburbs. |
| 9 | **Georgia**: Atlanta-Sandy Springs-Roswell | 4.7 | 4.2 | 2.9 | 4.0 | 4.5 | Huge, diverse SMB base, but inbox/agency competition is heavy. Use outer suburbs and association/referral entry points. |
| 10 | **Colorado**: Colorado Springs | 4.0 | 4.4 | 3.8 | 4.3 | 4.5 | Good income/digital mix, less crowded than Denver. Strong for contractors, home care, professional practices — smaller list. |

**Deliberately discounted:** New York, Los Angeles, San Francisco, Seattle, Boston, Miami. Willingness to pay is high, but agency saturation, paid-media cost, and sophisticated procurement raise acquisition effort for a new offshore vendor.

**Worth monitoring but not independently sourced here (secondary passes only):** Columbus, OH; Augusta, GA; Naperville, IL. Treat as exploratory, small-batch tests, not a primary allocation, until we have our own data.

---

## Table 3 — Best niche × location combinations

| Rank | Combo | Best initial offer | Ticket + retainer | Cycle | Why it converts |
|---|---|---|---|---|---|
| 1 | Plumbers/HVAC × Tampa Bay + Orlando | 10–12 page mobile lead site, emergency CTA, service-area pages, review blocks, call tracking, CRM handoff | $2k–$4k + $1k–$2k/mo | 7–21 days | Urgent search behavior, visible site/no-site gaps, climate-driven demand, abundant directory leads |
| 2 | Med spas × DFW suburbs | Premium treatment-site redesign, booking, provider credentials, compliant before/after system | $3.5k–$5k + $1.5k–$4k/mo | 7–21 days | High revenue per client, fast category growth, dense affluent suburbs, owner-led decisions |
| 3 | Remodelers/roofers × Raleigh + Charlotte | Portfolio-first redesign, financing info, project filters, service-area pages, quote qualification | $3k–$5k + $1k–$3k/mo | 10–30 days | Strong metro growth and housing/service demand; one job covers the site cost |
| 4 | Dental/orthodontic × Phoenix-Mesa-Chandler | New-patient site, online scheduling, insurance/financing clarity, reviews, secure PMS integration | $3k–$5k + $1k–$2.5k/mo | 14–45 days | Large family market, high patient lifetime value, strong mobile/local discovery |
| 5 | Home-care agencies × Raleigh + Charlotte | Family-trust site, caregiver-recruiting pages, referral intake, secure scheduling/portal links | $3k–$5k + $1k–$2.5k/mo | 14–45 days | Structural care demand, fast-growing metros, two-sided lead/recruiting ROI |
| 6 | Commercial cleaning × DFW | B2B capability site, vertical pages, certifications, facility quote form | $2k–$3.5k + $750–$1.5k/mo | 7–21 days | Huge business base, recurring contract value, sourceable owner/sales contacts |
| 7 | Accounting/bookkeeping × Salt Lake + Provo | Secure-trust redesign, advisory positioning, niche pages, portal integration, appointment booking | $2k–$4k + $750–$2k/mo | 7–30 days | Digitally mature buyers, strong payment proxy, clear security/portal narrative |
| 8 | Wedding venues × Charleston | Gallery-led venue site, transparent starting prices, tour booking, vendor integrations | $2.5k–$5k + $500–$1.5k/mo | 7–30 days | Destination-wedding demand; visuals matter; venue is an early high-value couple decision |
| 9 | Estate/family law × Arlington + Richmond | Authority site, practice-area pages, review proof, 24/7 screened intake, Clio/Lawmatics integration | $3.5k–$5k + $1.5k–$3k/mo | 14–45 days | High-value cases, strong income/payment proxy — offset by vendor fatigue and ethics review |
| 10 | Behavioral-health groups × Austin-Round Rock | Specialty/location pages, therapist matching, secure booking, insurance clarity, accessibility pass | $2k–$4k + $750–$2k/mo | 7–30 days | Fast category growth, digital-first population; solo practices excluded to protect budget quality |

**Recommended first campaign:** Tampa Bay + Orlando plumbers/HVAC at a fixed $2,500 conversion rebuild, followed by a DFW med-spa campaign at $4,000–$5,000. This combo has the fastest close, clearest urgency trigger, and highest sourceable volume.

---

## Decision model (how these rankings were built)

- **Niche score:** demand/urgency 25%, buyer ability & payment capacity 20%, decision speed 15%, prospect sourceability 15%, retainer/upsell fit 15%, competitive/DIY risk 10%.
- **Location score:** addressable SMB/startup activity 30%, household/business spending 20%, inverse web-agency crowding 20%, payment/operating-stability proxy 15%, digital-readiness proxy 15%.
- "Payment reliability" is not a regional character judgment — it's a proxy built from employer-firm depth, professional-service mix, income, economic stability, and how easy it is to verify a business is real and operating.
