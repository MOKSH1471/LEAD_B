# Compliance, qualification, credibility, and payments

## CAN-SPAM compliance (required for every send)

CAN-SPAM applies to B2B commercial email in the US, not just consumer marketing. It does **not** require opt-in consent to send a first email, but it does require:

- **Accurate header information** — the "from" name and domain must genuinely identify the sender; no misleading "from" lines.
- **Accurate, non-deceptive subject lines** — the subject must reflect the actual content of the email.
- **Clear identification as an ad** where applicable, and a **valid physical postal address** in every email (the agency's real address — a registered business address is fine).
- **A working opt-out mechanism** in every email, and opt-outs must be honored within **10 business days**.
- No harvested or falsified sender information, and no relaying through someone else's system without permission.

If the sending bot doesn't currently include a physical address and one-click opt-out in its footer, that's a compliance gap to close before scaling volume — flag it rather than treating it as optional polish.

## Lead qualification filter

Apply before spending outreach effort on a lead:

**Prioritize:**
- 5–50 employees
- 20+ credible reviews, rating ~4.2+
- Operating history of 2+ years
- Actively recruiting or running ads
- More than one service or location
- Plausible average customer value above $1,000
- Verifiable: real license (where applicable), named owner, real address, working phone

**Down-rank or skip:**
- Unresolved public complaints (BBB, reviews)
- Very recent business formation with no track record
- Unclear or unverifiable ownership
- Only a WhatsApp number or free-email address as contact
- No review history at all
- Any request or expectation of a guaranteed revenue/ranking outcome — this is a red flag on the buyer relationship, not just a compliance issue

## Credibility bridge for an India-based agency

The goal is to dismantle the "unreliable offshore freelancer" assumption without pretending to be something you're not.

- **Be transparent, don't overclaim:** "India-based delivery team serving US local-service businesses" is honest and lands fine. Never imply a US office or US-based staff.
- **Commit to a concrete overlap window**, not a vague "flexible hours" claim: 9am–1pm ET overlaps roughly 6:30–10:30pm IST during US daylight time, and 7:30–11:30pm IST during standard time. State the actual window in outreach and on the site.
- **Use a domain email**, not a generic Gmail/Yahoo address, for all outreach.
- **Name a real project owner** the client can reach — not a shared inbox or "the team."
- **Offer a one-page SOW, a staging link, and a response-time SLA** — these are the concrete artifacts that substitute for "we have a US office."
- **Lead with one vertical demo and one specific teardown**, not a generic free mockup. A 60–90 second personalized audit of their actual site is far more convincing than an unpaid spec build — and keep it narrow enough that it doesn't become free work.
- **For regulated niches** (health, dental, legal, accounting): integrate established secure portals/schedulers rather than building custom intake. Never collect PHI, SSNs, tax documents, or confidential legal facts through ordinary website contact forms — confirm which vendor in the stack actually signs a BAA or provides the required security controls before promising compliance.

## Payment setup

- **Default: Wise Business (USD/ACH).** Supports receiving from many countries, gives US local account details, and domestic ACH is generally free.
- **Second option: Payoneer.** Balances typically withdraw to an Indian bank account within about 24 hours.
- **Backup: PayPal invoicing** for clients who specifically want a card-friendly option.
- **Do not promise Stripe** as a payment option. As of this research, Stripe India's own site describes access as invite-only ("Request an invite"), so it shouldn't be presented to prospects as available. Re-check this periodically — fintech access policies change, and this could open up.
- Put all processor fees, currency handling, tax responsibility, and refund terms explicitly in the SOW.
- Payment schedule: **50% upfront, 25% at staging approval, 25% before launch/domain handoff.** Retainers are prepaid monthly.
- The SOW should also cap revision rounds, define what content the client owes you (copy, photos, logins), include a 3–5 business-day client acceptance window, allow pausing work for late payment, and transfer IP only after final payment clears.

## Tracking and kill criteria

Track, per niche×metro cell: positive replies, booked calls, proposals sent, closes, average days-to-close, and cash collected. After roughly 100 delivered emails in a cell, if the positive-reply rate is under ~2%, treat that as a signal to revise the angle or drop the cell — unless there's a clear, separate deliverability or list-quality problem to fix first.
