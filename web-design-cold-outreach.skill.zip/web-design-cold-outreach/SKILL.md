---
name: web-design-cold-outreach
description: Use this skill for ANY task related to our web design agency's US client acquisition — drafting cold outreach emails, LinkedIn messages, or follow-up sequences to US small-business prospects; scoring or qualifying a lead/business as a target; deciding which niche or metro to prospect next; building or checking a pricing quote; or writing prospect list / lead-sourcing instructions for our outreach bot. Trigger this even when the user just pastes a business name, city, and niche with no explicit ask — that is a request to draft an outreach email. Covers our validated target niches (home services, med spas, remodelers, dental, and more), priority Sun Belt geographies, our three-tier pricing ($1,500–$5,000 projects, $1,000–$4,000/month retainers), the India-based credibility bridge, and CAN-SPAM-compliant sequencing. Always consult this before writing agency outreach copy, even for "just a quick email."
---

# Web Design Agency — Cold Outreach

We build premium-looking websites for US small businesses at a competitive, India-based cost. Our main growth lever is cold email (increasingly run through an automated sending bot), backed by LinkedIn and referral partners. This skill packages the market research behind who to contact, what to offer them, and what to say — so every email the bot sends is targeted instead of generic.

The underlying research is a targeting **hypothesis**, not a guarantee — see "Confidence and updating" at the bottom before treating any number here as fixed truth.

## The workflow, end to end

For any single lead (business name + niche + city, at minimum), do these steps in order. For a batch/list task, apply the same logic per lead, or produce a prioritized list using Steps 1–3 only.

### Step 1 — Confirm niche fit
Check the lead's niche against `references/market-research.md` → Table 1. Niches are grouped into tiers:
- **Tier A** (best fit, fastest path to a close): home services contractors (HVAC/plumbing/electrical), remodelers/roofers, med spas, dental practices.
- **Tier B** (good fit, longer cycle or narrower buyer pool): home-care/senior-care agencies, small law firms (family/immigration/estate — never personal injury), accounting/bookkeeping firms.
- **Tier C** (plausible, less rigorously evidenced — test in small batches and track results before scaling): veterinary clinics, real estate agents, behavioral-health group practices, wedding venues/event vendors, commercial cleaning/facility services.
- **Excluded for now**: restaurants, generic e-commerce startups, coaches, pre-revenue startups, personal injury law. High churn, DIY-platform substitution, or price-shopping buyers. Take these only via warm referral, not cold outreach.

If a lead falls outside these categories entirely, say so rather than forcing a template — don't invent a niche fit.

### Step 2 — Confirm geography priority
Check the lead's state/metro against `references/market-research.md` → Table 2. Priority order: **TX, NC, UT, FL, VA, SC, AZ, TN, GA, CO**, with specific metros ranked inside each state. Avoid leading with NY, LA, SF, Seattle, Boston, or Miami as first targets — buyer willingness-to-pay is high there, but so is agency saturation and procurement complexity for a new offshore vendor.

A lead outside these states isn't disqualified — it's just lower-priority. Say so and proceed if the user still wants it.

### Step 3 — Qualify the lead
Before drafting anything, sanity-check the lead against this filter (full detail in `references/compliance-and-payments.md`):

**Good signs:** 5–50 employees, 20+ reviews at 4.2+ rating, 2+ years operating, actively advertising or hiring, more than one service/location, plausible average customer value above $1,000, a named owner and a real, verifiable address/phone/license.

**Red flags — down-rank or skip:** unresolved complaints, very recent formation, unclear ownership, only a WhatsApp/free-email contact, no review history, or any signal they expect a revenue guarantee.

If you don't have enough information to qualify the lead, say what's missing rather than assuming it passes.

### Step 4 — Find the personalization trigger
Cold email only works when it references something real and specific. Look for one of these before writing anything (from the lead's site, Google Business Profile, or socials):
- Broken, slow, or non-mobile-friendly site
- No online booking/quote/contact-form path
- Running paid ads that land on a weak page
- Outdated design/copy relative to a competitor
- Strong reviews but a website that undersells them
- Recent trigger event: new location, ownership change, active hiring

**No visible trigger = don't send a cold email yet.** Route it to the referral-partner or warm-list track instead of forcing a generic pitch — a trigger-less email is what makes cold outreach feel like spam.

### Step 5 — Pick the offer
Use the tier structure (full ranges by niche in `references/market-research.md` → Table 3):
- **Starter rebuild:** $1,500–$2,500 — 5–8 pages, fixed template system, mobile-first, booking/quote form, analytics. 10–14 business days.
- **Growth site:** $3,000–$5,000 — 10–20 pages, service/location SEO structure, integrations, migration. 3–5 weeks.
- **Retainer:** $1,000–$4,000/month — only pitch this once it's built around recurring outcomes (local SEO, conversion testing, review workflows, reporting, maintenance). A retainer that's just hosting won't hold this price.

Match the specific dollar figure to the niche's practical budget band in Table 3, not a flat number for every lead.

### Step 6 — Draft the email
Read `references/email-templates.md` for full templates, subject-line bank, and copy rules. The compressed version: one observed issue → one business consequence → one small piece of proof → one low-friction 15-minute ask. Keep it under ~130 words. No "I noticed your website could use some work" filler, no guaranteed-results language, no walls of bullet points in a first email.

### Step 7 — Set the sequence
Don't one-and-done a lead. Use the 16-day cadence:
1. **Day 1** — the observed-issue email (Step 6).
2. **Day 3** — LinkedIn connection request, one line referencing the same observation, no pitch.
3. **Day 5** — a short teardown (60–90 sec Loom or two annotated screenshots).
4. **Day 10** — the concrete scope, timeline, and price band.
5. **Day 16** — a short close-the-loop message with a clean opt-out.

Volume discipline matters more than list size: **20–30 highly qualified sends per day**, not mass blasts — small hand-researched batches consistently outperform generic ones. After ~100 delivered emails in a given niche×metro cell, if positive replies are under ~2%, revise the angle or drop that cell rather than pushing more volume at it.

### Step 8 — Apply the credibility and compliance layer to every send
This isn't optional flavor text — it's what makes an India-based agency's outreach land instead of getting flagged. Full detail in `references/compliance-and-payments.md`:
- Be transparent that delivery is India-based; never imply a US office.
- State a concrete US business-hours overlap window.
- Send from a domain email, name a real project owner, offer a staging link and a response-time SLA.
- Default payment path is **Wise Business (USD/ACH)**, second option **Payoneer**, backup **PayPal invoicing**. Do not promise **Stripe** — as of this research, Stripe India requires an invite and shouldn't be presented as available; re-verify this periodically since it can change.
- Every commercial email must be CAN-SPAM compliant: accurate sender/subject, a real physical postal address, a working opt-out honored within 10 business days.
- Payment terms: 50% upfront, 25% at staging approval, 25% before launch/handoff.

## When information is incomplete
If the bot hands you only a business name + city (no niche, no site, no trigger), do your best: infer the likely niche from the name, pull the geography priority for that city, and draft using a generic-but-still-specific trigger placeholder (e.g., "[reference: mobile site speed / no online booking]") clearly marked for the human or bot to fill in before sending — don't fabricate a specific observation you haven't actually seen.

## Confidence and updating
Budget ranges, decision-speed windows, and reply-rate targets in the reference files are **modeled estimates**, not audited niche averages — the source research is explicit about this. Treat them as a starting hypothesis. Once real send data exists (aim for 100–200 qualified contacts per niche×metro cell), prioritize that data over these numbers, and flag to the user when actual results diverge meaningfully so the tables can be revised.

## Reference files
- `references/market-research.md` — full niche table, state/metro table, niche×location combos, and where to actually source each niche's contact lists.
- `references/email-templates.md` — subject-line bank, the day-1/day-5/day-10/day-16 templates, and copy rules.
- `references/compliance-and-payments.md` — CAN-SPAM checklist, qualification/red-flag list, credibility-bridge bullets, and payment setup.
